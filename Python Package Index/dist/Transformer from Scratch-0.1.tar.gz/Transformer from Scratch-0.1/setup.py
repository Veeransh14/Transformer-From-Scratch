from setuptools import setup, find_packages
setup(
    name= "Transformer from Scratch",
    version="0.1",
    description="This is transformer from scratch",
    packages = find_packages(),
    github_Repository="https://github.com/Veeransh14/Transformer-From-Scratch",
    install_requires=['numpy','cupy'],
)
